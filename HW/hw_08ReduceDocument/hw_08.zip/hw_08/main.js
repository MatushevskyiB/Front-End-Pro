//Методы массивов.

/* С помощью метода reduce необходимо перебрать массив и составить объект, у которого ключ — уникальный элемент массива, значение — сколько раз он встречается в массиве. Например, перебирая массив ['ololo', 'anna', 'red', 'ololo', 'qwe', 'anna', 'ololo'] мы получим {ololo: 3, anna: 2, red: 1, qwe: 1] */

let someArr = [16,-37,54,-4,72,-56,47,4,-16,25,-37,46,4,-51,27,-63,4,-54,76,-4,12,-35,4,47];
console.log("Масив:\n" + someArr); 

let result = someArr.reduce (function (accum, item) {
        accum[item] = (someArr.filter (el => el === item)).length;
        //console.log (accum);
        //console.log ("item" + item); 
        return accum
}, {})

console.log ("\nОб'єкт:")
console.log (result);

//Документ

/* Создать список товаров (массив). У товара должно быть имя его цена и количество.

Вывести этот список на страницу (имя, цена и количество должны быть выведены с новой строчки). Для каждого второго товара сделать цвет фона серым. */

let productList = [
    {name : "phone", price : "300$", amount : 50},
    {name : "headphones", price : "50$", amount : 60},
    {name : "charger", price : "10$", amount : 80},
    {name : "case", price : "5$", amount : 80},
];
console.log ("\nСписок товарів:")
console.table(productList);

productList.forEach(function(obj) {
    for (const kay in obj) { 
        const element = obj[kay];
        document.querySelector(".body").insertAdjacentHTML("beforeend", `<li class="li">${kay}:${element}</li>`);
    }//вставляю у кінець body список li кожним пунктом якого є ключ і властивість об'єкту з масиву productList
});

document.querySelectorAll(".li:nth-child(6n)").forEach(elem => elem.style.backgroundColor = "gray");
//querySelectorAll - повертає масив тому для застосування змін до його елементів потрібен forEach
//оскільки треба було змінити background-сolor кожному 2-ому товару (я так зрозумів йшлося про назву) я скористався псевдокласом :nth-child(6n)