"use strict"

let ageImportantPerson = Number (prompt ("Введіть, будь ласка, Ваш вік", 18));

//Без перевірки на наявність слів

if ((ageImportantPerson>=2 && ageImportantPerson<=4) || (ageImportantPerson>=22&&ageImportantPerson<=24) ||
(ageImportantPerson>=32 && ageImportantPerson<=34) || (ageImportantPerson>=42&&ageImportantPerson<=44) ||
(ageImportantPerson>=52 && ageImportantPerson<=54) || (ageImportantPerson>=62&&ageImportantPerson<=64) ||
(ageImportantPerson>=72 && ageImportantPerson<=74) || (ageImportantPerson>=82&&ageImportantPerson<=84) ||
(ageImportantPerson>=92 && ageImportantPerson<=94) || (ageImportantPerson>=102&&ageImportantPerson<=104) ||
(ageImportantPerson>=122 && ageImportantPerson<=124)) {
    alert (`${ageImportantPerson} роки`);
} else if (ageImportantPerson == 1 || ageImportantPerson == 21 || ageImportantPerson == 31 ||
    ageImportantPerson == 41 || ageImportantPerson == 51 || ageImportantPerson == 61 ||
    ageImportantPerson == 71 || ageImportantPerson == 81 || ageImportantPerson == 91 ||
    ageImportantPerson == 101 || ageImportantPerson == 121) {
    alert (`${ageImportantPerson} рік`);
} else {
    alert (`${ageImportantPerson} років`);
}

// З перевіркою

/* if ((ageImportantPerson>=2 && ageImportantPerson<=4) || (ageImportantPerson>=22&&ageImportantPerson<=24) ||
(ageImportantPerson>=32 && ageImportantPerson<=34) || (ageImportantPerson>=42&&ageImportantPerson<=44) ||
(ageImportantPerson>=52 && ageImportantPerson<=54) || (ageImportantPerson>=62&&ageImportantPerson<=64) ||
(ageImportantPerson>=72 && ageImportantPerson<=74) || (ageImportantPerson>=82&&ageImportantPerson<=84) ||
(ageImportantPerson>=92 && ageImportantPerson<=94) || (ageImportantPerson>=102&&ageImportantPerson<=104) ||
(ageImportantPerson>=122 && ageImportantPerson<=124)) {
    alert (`${ageImportantPerson} роки`);
} else if (ageImportantPerson == 1 || ageImportantPerson == 21 || ageImportantPerson == 31 ||
    ageImportantPerson == 41 || ageImportantPerson == 51 || ageImportantPerson == 61 ||
    ageImportantPerson == 71 || ageImportantPerson == 81 || ageImportantPerson == 91 ||
    ageImportantPerson == 101 || ageImportantPerson == 121) {
    alert (`${ageImportantPerson} рік`);
} else if ((ageImportantPerson>=5 && ageImportantPerson<=20) || (ageImportantPerson>=25&&ageImportantPerson<=30) ||
(ageImportantPerson>=35 && ageImportantPerson<=40) || (ageImportantPerson>=45&&ageImportantPerson<=50) ||
(ageImportantPerson>=55 && ageImportantPerson<=60) || (ageImportantPerson>=65&&ageImportantPerson<=70) ||
(ageImportantPerson>=75 && ageImportantPerson<=80) || (ageImportantPerson>=85&&ageImportantPerson<=90) ||
(ageImportantPerson>=95 && ageImportantPerson<=100) || (ageImportantPerson>=105&&ageImportantPerson<=120) ||
(ageImportantPerson>=125 && ageImportantPerson<=130)) {
    alert (`${ageImportantPerson} років`);
} else {
    alert ("Введіть, будь ласка, значення числом")
} */