"use strict"
let importantPerson = prompt ("Введіть, будь ласка, Ваше ім'я", "Гість");
let birthYearImportantPerson = prompt ("Введіть, будь ласка, Ваш рік народження", 2002);
let ageImportantPerson = (2020 - birthYearImportantPerson)
alert (`Привіт ${importantPerson}, ${ageImportantPerson} років`);