"use strict"
let importantPerson = prompt ("Введіть, будь ласка, Ваше ім'я", "Гість");
let ageImportantPerson = prompt ("Введіть, будь ласка, Ваш вік (кількість повних років)", 18);
alert (`Привіт ${importantPerson}, ${ageImportantPerson} років`);